// 📘 Load notes dynamically from notes.json
async function loadNotes(subject) {
  try {
    let res = await fetch("../../../data/notes.json");
    let data = await res.json();
    let list = document.getElementById("notes-list");
    list.innerHTML = "";

    if (data[subject]) {
      // Case 1: subject is an array of topics
      if (Array.isArray(data[subject])) {
        data[subject].forEach(item => {
          let li = document.createElement("li");
          li.textContent = item;
          list.appendChild(li);
        });
      } 
      // Case 2: subject is an object with units
      else if (typeof data[subject] === "object") {
        for (let unit in data[subject]) {
          let li = document.createElement("li");
          li.innerHTML = `<strong>${unit}:</strong> ${data[subject][unit]}`;
          list.appendChild(li);
        }
      }
    } else {
      list.innerHTML = "<li>No notes available for this subject yet.</li>";
    }
  } catch (error) {
    console.error("Error loading notes:", error);
  }
}
